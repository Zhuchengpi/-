#include "include_03.h"

void EPWM3_int(void)
{
    EALLOW;
    EPwm1Regs.TBCTL.bit.SYNCOSEL = 0;
    EPwm2Regs.TBCTL.bit.SYNCOSEL = 0;
    EPwm3Regs.TBCTL.bit.SYNCOSEL = 0;

    EPwm1Regs.TBCTL.bit.PHSEN = 1;
    EPwm2Regs.TBCTL.bit.PHSEN = 1;
    EPwm3Regs.TBCTL.bit.PHSEN = 1;

    EPwm1Regs.TBPRD = PWM_PeriodMax;    //  7500
    EPwm2Regs.TBPRD = PWM_PeriodMax;
    EPwm3Regs.TBPRD = PWM_PeriodMax;

    EPwm1Regs.TBPHS.half.TBPHS = 0; //��ǰ5999��ʱ�����ڲ����жϣ���0.1ms
    EPwm2Regs.TBPHS.half.TBPHS = 0;
    EPwm3Regs.TBPHS.half.TBPHS = 0;

    EPwm1Regs.TBCTL.all = 0xA00A;
    EPwm2Regs.TBCTL.all = 0xA00A;
    EPwm3Regs.TBCTL.all = 0xA00A;

    EPwm1Regs.CMPCTL.all = 0;
    EPwm2Regs.CMPCTL.all = 0;
    EPwm3Regs.CMPCTL.all = 0;

    EPwm1Regs.AQCTLA.all = 0x0090;
    EPwm2Regs.AQCTLA.all = 0x0090;
    EPwm3Regs.AQCTLA.all = 0x0090;

    EPwm1Regs.DBCTL.all = 0x000B;  // 0x0003
    EPwm2Regs.DBCTL.all = 0x000B;  // ȫһ��  �͵�ƽ
    EPwm3Regs.DBCTL.all = 0x000B;

    EPwm1Regs.DBFED = PWM_Deadband;
    EPwm1Regs.DBRED = PWM_Deadband;
    EPwm2Regs.DBFED = PWM_Deadband;
    EPwm2Regs.DBRED = PWM_Deadband;
    EPwm3Regs.DBFED = PWM_Deadband;
    EPwm3Regs.DBRED = PWM_Deadband;

    EPwm1Regs.PCCTL.all = 0;
    EPwm2Regs.PCCTL.all = 0;
    EPwm3Regs.PCCTL.all = 0;
    /*
     EPwm1Regs.TZSEL.all = 0;
     EPwm2Regs.TZSEL.all = 0;
     EPwm3Regs.TZSEL.all = 0;
     */

    //�Ƚ�����������¼�
    EPwm1Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_COMP1OUT; // DCAH = Comparator 1 output
    EPwm1Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_COMP2OUT;

    EPwm2Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_COMP1OUT; // DCAH = Comparator 1 output
    EPwm2Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_COMP2OUT;

    EPwm3Regs.DCTRIPSEL.bit.DCBHCOMPSEL = DC_COMP1OUT; // DCAH = Comparator 1 output
    EPwm3Regs.DCTRIPSEL.bit.DCAHCOMPSEL = DC_COMP2OUT;

//DCAEVT1
    // �Ƚ�������ߵ�ƽ��Ч
    EPwm1Regs.TZDCSEL.bit.DCAEVT1 = TZ_DCAH_HI; // DCAEVT2 = DCAH highwill become active
    EPwm2Regs.TZDCSEL.bit.DCAEVT1 = TZ_DCAH_HI;
    EPwm3Regs.TZDCSEL.bit.DCAEVT1 = TZ_DCAH_HI;

    EPwm1Regs.TZDCSEL.bit.DCBEVT1 = TZ_DCAH_HI; // DCAEVT2 = DCAH highwill become active
    EPwm2Regs.TZDCSEL.bit.DCBEVT1 = TZ_DCAH_HI;
    EPwm3Regs.TZDCSEL.bit.DCBEVT1 = TZ_DCAH_HI;

//EVT1SRCSEL
    //�������ź�
    EPwm1Regs.DCACTL.bit.EVT1SRCSEL = DC_EVT2; // DCAEVT2 = DCAEVT2 (not filtered)
    EPwm2Regs.DCACTL.bit.EVT1SRCSEL = DC_EVT2;
    EPwm3Regs.DCACTL.bit.EVT1SRCSEL = DC_EVT2;

    EPwm1Regs.DCBCTL.bit.EVT1SRCSEL = DC_EVT2; // DCAEVT2 = DCAEVT2 (not filtered)
    EPwm2Regs.DCBCTL.bit.EVT1SRCSEL = DC_EVT2;
    EPwm3Regs.DCBCTL.bit.EVT1SRCSEL = DC_EVT2;

//EVT1FRCSYNCSEL
    //�����첽�ź�
    EPwm1Regs.DCACTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC; // Take async path // Enable DCAEVT2 as a
    EPwm2Regs.DCACTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC;
    EPwm3Regs.DCACTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC;

    EPwm1Regs.DCBCTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC; // Take async path // Enable DCAEVT2 as a
    EPwm2Regs.DCBCTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC;
    EPwm3Regs.DCBCTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC;

//DCAEVT1
    EPwm1Regs.TZSEL.bit.DCAEVT1 = 1;
    EPwm2Regs.TZSEL.bit.DCAEVT1 = 1;
    EPwm3Regs.TZSEL.bit.DCAEVT1 = 1;

    EPwm1Regs.TZSEL.bit.DCBEVT1 = 1;
    EPwm2Regs.TZSEL.bit.DCBEVT1 = 1;
    EPwm3Regs.TZSEL.bit.DCBEVT1 = 1;

    EPwm1Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWM1A will go low
    EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWM1A will go low
    EPwm3Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWM1A will go low

    EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_LO;
    EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_LO;
    EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_LO;


    EDIS;
    /* Disable EALLOW*/
}

void HVDMC_Protection(void)
{

    EALLOW;

    EPwm1Regs.TZSEL.bit.CBC6 = 0x1;
    EPwm2Regs.TZSEL.bit.CBC6 = 0x1;
    EPwm3Regs.TZSEL.bit.CBC6 = 0x1;

    EPwm1Regs.TZSEL.bit.OSHT1 = 1;  //enable TZ1 for OSHT
    EPwm2Regs.TZSEL.bit.OSHT1 = 1;  //enable TZ1 for OSHT
    EPwm3Regs.TZSEL.bit.OSHT1 = 1;  //enable TZ1 for OSHT

    EPwm1Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWMxA will go low
    EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_LO; // EPWMxB will go low

    EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWMxA will go low
    EPwm2Regs.TZCTL.bit.TZB = TZ_FORCE_LO; // EPWMxB will go low

    EPwm3Regs.TZCTL.bit.TZA = TZ_FORCE_LO; // EPWMxA will go low
    EPwm3Regs.TZCTL.bit.TZB = TZ_FORCE_LO; // EPWMxB will go low

    EDIS;

//************************** End of Prot. Conf. ***************************//
}

void STOP_CAR(void)
{
    EALLOW;
    EPwm1Regs.TZFRC.bit.OST = 1;  // ��������
    EPwm2Regs.TZFRC.bit.OST = 1;
    EPwm3Regs.TZFRC.bit.OST = 1;
    EDIS;
}

void START_CAR(void)
{
    EALLOW;
    EPwm1Regs.TZCLR.bit.OST = 1;    //  �������
    EPwm2Regs.TZCLR.bit.OST = 1;
    EPwm3Regs.TZCLR.bit.OST = 1;
    EDIS;
}

void PWMDAC_int(void)
{
    EALLOW;
    EPwm4Regs.TBCTL.bit.SYNCOSEL = 0;
    EPwm4Regs.TBCTL.bit.PHSEN = 1;
    EPwm4Regs.TBPRD = PWM_PeriodMax;
    EPwm4Regs.TBPHS.half.TBPHS = 0;
    EPwm4Regs.TBCTL.all = 0xA00A;
    EPwm4Regs.CMPCTL.all = 0x0000;
    EPwm4Regs.AQCTLA.all = 0x0090;
    EPwm4Regs.AQCTLB.all = 0x0900;
    EPwm4Regs.DBCTL.all = 0x0000;
    EPwm4Regs.PCCTL.all = 0x0000;
    EPwm4Regs.TZSEL.all = 0x0000;
    EPwm4Regs.TZCTL.all = 0x0000;
    EDIS;
}

//===========================================================================
// No more.
//===========================================================================
