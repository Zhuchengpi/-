#include "include_03.h"

#define ACQS 11
#define tirg 5

void ADC_SOC_int(void)
{
    InitAdc();
    AdcOffsetSelfCal(0);
    //  Configure ADC to sample the temperature sensor on ADCIN5:
    // The output of Piccolo temperature sensor can be internally connected to the ADC through ADCINA5
    // via the TEMPCONV bit in the ADCCTL1 register. When this bit is set, any voltage applied to the external
    // ADCIN5 pin is ignored.
    EALLOW;
    AdcRegs.ADCCTL1.bit.TEMPCONV = 1; //Connect internal temp sensor to channel ADCINA5.
    EDIS;
    //  Continue configuring ADC to sample the temperature sensor on ADCIN5:
    // Since the temperature sensor is connected to ADCIN5, configure the ADC to sample channel ADCIN5
    // as well as the ADC SOC trigger and ADCINTs preferred. This example uses EPWM1A to trigger the ADC
    // to start a conversion and trips ADCINT1 at the end of the conversion.

    //Note: The temperature sensor will be double sampled to apply the workaround for rev0 silicon errata for the ADC 1st sample issue
    EALLOW;
    AdcRegs.ADCCTL1.bit.INTPULSEPOS = 1;  //ADCINT1 trips after AdcResults latch
    AdcRegs.INTSEL1N2.bit.INT1E = 1;     //Enabled ADCINT1
    AdcRegs.INTSEL1N2.bit.INT1CONT = 0;     //Disable ADCINT1 Continuous mode
    AdcRegs.INTSEL1N2.bit.INT1SEL = 1;   //setup EOC1 to trigger ADCINT1 to fire

    /*    // Configure SOC0 to sample ADCINA0
     AdcRegs.ADCSOC0CTL.bit.CHSEL = 0;    // set SOC0 channel select to ADCINA0
     AdcRegs.ADCSOC0CTL.bit.TRIGSEL = tirg;  // set SOC0 start trigger on EPWM1A
     AdcRegs.ADCSOC0CTL.bit.ACQPS = ACQS;   //set SOC0 S/H Window to 37 ADC Clock Cycles, (36 ACQPS plus 1)
     */
    // Configure SOC1 to sample ADCINA1
    AdcRegs.ADCSOC1CTL.bit.CHSEL = 1;    // set SOC1 channel select to ADCINA1
    AdcRegs.ADCSOC1CTL.bit.TRIGSEL = tirg;  // set SOC1 start trigger on EPWM1A
    AdcRegs.ADCSOC1CTL.bit.ACQPS = ACQS; //set SOC1 S/H Window to 37 ADC Clock Cycles, (36 ACQPS plus 1) errata workaround

    // Configure SOC2 to sample ADCINA2
    AdcRegs.ADCSOC2CTL.bit.CHSEL = 2;    // set SOC2 channel select to ADCINA2
     AdcRegs.ADCSOC2CTL.bit.TRIGSEL = tirg;  // set SOC2 start trigger on EPWM1A
     AdcRegs.ADCSOC2CTL.bit.ACQPS = ACQS;

    // Configure SOC3 to sample ADCINA3
    AdcRegs.ADCSOC3CTL.bit.CHSEL = 3;   // set SOC3 channel select to ADCINA3
    AdcRegs.ADCSOC3CTL.bit.TRIGSEL = tirg;  // set SOC3 start trigger on EPWM1A
    AdcRegs.ADCSOC2CTL.bit.ACQPS = ACQS;

    // Configure SOC4 to sample ADCINA4
    AdcRegs.ADCSOC4CTL.bit.CHSEL = 4;    // set SOC4 channel select to ADCINA7
     AdcRegs.ADCSOC4CTL.bit.TRIGSEL = tirg;  // set SOC4 start trigger on EPWM1A
     AdcRegs.ADCSOC4CTL.bit.ACQPS = ACQS;

     /*AdcRegs.ADCSOC5CTL.bit.CHSEL = 5;      //����ͨ��
     AdcRegs.ADCSOC5CTL.bit.TRIGSEL = tirg; //����Դ
     AdcRegs.ADCSOC5CTL.bit.ACQPS = ACQS;   //�������

     AdcRegs.ADCSOC6CTL.bit.CHSEL = 6;
     AdcRegs.ADCSOC6CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC6CTL.bit.ACQPS = ACQS;*/

    AdcRegs.ADCSOC7CTL.bit.CHSEL = 7;
    AdcRegs.ADCSOC7CTL.bit.TRIGSEL = tirg;
    AdcRegs.ADCSOC7CTL.bit.ACQPS = ACQS;

    /*AdcRegs.ADCSOC8CTL.bit.CHSEL = 8;
     AdcRegs.ADCSOC8CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC8CTL.bit.ACQPS = ACQS;

     AdcRegs.ADCSOC9CTL.bit.CHSEL = 9;
     AdcRegs.ADCSOC9CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC9CTL.bit.ACQPS = ACQS;

     AdcRegs.ADCSOC10CTL.bit.CHSEL = 10;
     AdcRegs.ADCSOC10CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC10CTL.bit.ACQPS = ACQS;

     AdcRegs.ADCSOC11CTL.bit.CHSEL = 11;
     AdcRegs.ADCSOC11CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC11CTL.bit.ACQPS = ACQS;

     AdcRegs.ADCSOC12CTL.bit.CHSEL = 12;
     AdcRegs.ADCSOC12CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC12CTL.bit.ACQPS = ACQS;

     AdcRegs.ADCSOC13CTL.bit.CHSEL = 13;
     AdcRegs.ADCSOC13CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC13CTL.bit.ACQPS = ACQS;

     AdcRegs.ADCSOC14CTL.bit.CHSEL = 14;
     AdcRegs.ADCSOC14CTL.bit.TRIGSEL = tirg;
     AdcRegs.ADCSOC14CTL.bit.ACQPS = ACQS;*/

    AdcRegs.ADCSOC15CTL.bit.CHSEL = 15;
    AdcRegs.ADCSOC15CTL.bit.TRIGSEL = tirg;
    AdcRegs.ADCSOC15CTL.bit.ACQPS = ACQS;

    EDIS;

    // Assumes ePWM1 clock is already enabled in InitSysCtrl();
    EPwm1Regs.ETSEL.bit.SOCAEN = 1;        // Enable SOC on A group
    EPwm1Regs.ETSEL.bit.SOCASEL = 4;     // Select SOC from from CPMA on upcount
    EPwm1Regs.ETPS.bit.SOCAPRD = 1;        // Generate pulse on 1st event
    EPwm1Regs.CMPA.half.CMPA = 0x0080;   // Set compare A value
}

//===========================================================================
// No more.
//===========================================================================
