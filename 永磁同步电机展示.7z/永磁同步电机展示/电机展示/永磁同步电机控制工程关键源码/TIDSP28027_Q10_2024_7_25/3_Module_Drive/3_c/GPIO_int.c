﻿#include "include_03.h"
#include "include_05.h"

void Init_Gpio_LED(void)
{
    EALLOW;
    GpioCtrlRegs.GPBDIR.bit.GPIO33 = 1;
    GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 0;
    EDIS;
}

void Init_Optocoupler(void)                  //74LVC244APW使能
{
    EALLOW;
    GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 0; // 0=GPIO
    GpioCtrlRegs.GPADIR.bit.GPIO12 = 1;  // 1=OUTput,  0=INput
    GpioDataRegs.GPASET.bit.GPIO12 = 0; //低电平
    EDIS;
}

void Init_3MotorGpio(void)
{
    EALLOW;
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;
    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1;
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1;
    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;
    GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1;

    GpioCtrlRegs.GPADIR.bit.GPIO0 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO1 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO2 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO3 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO4 = 1;
    GpioCtrlRegs.GPADIR.bit.GPIO5 = 1;

    EDIS;
}

//===========================================================================
// No more.
//===========================================================================
