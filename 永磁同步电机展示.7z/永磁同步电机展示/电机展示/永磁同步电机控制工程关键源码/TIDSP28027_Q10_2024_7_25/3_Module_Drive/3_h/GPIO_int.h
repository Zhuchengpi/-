
#include "include_03.h"

#ifndef GPIO_int_H
#define GPIO_int_H

#define LED_Blink GpioDataRegs.GPBTOGGLE.bit.GPIO33=1

void Init_Gpio_LED(void);
void Init_3MotorGpio(void);
void Init_Optocoupler(void);                  //74LVC244APWʹ��



#endif  // end of GPIO_int_H definition

//===========================================================================
// End of file.
//===========================================================================
