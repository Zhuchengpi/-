
#ifndef ADC_int_H
#define ADC_int_H
//#include "DSP28x_Project.h"

void   ADC_SOC_int(void ); //ADC��ʼ������

#endif  // end of ADC_int_H definition

//===========================================================================
// End of file.
//===========================================================================
