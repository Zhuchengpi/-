
//#include "DSP2833x_Project.h"

#ifndef CpuTimer_H
#define CpuTimer_H

void InitCpuTimer0(void);
interrupt void cpu_timer0_isr(void);
#endif  // end of CpuTimer definition

//===========================================================================
// End of file.
//===========================================================================
