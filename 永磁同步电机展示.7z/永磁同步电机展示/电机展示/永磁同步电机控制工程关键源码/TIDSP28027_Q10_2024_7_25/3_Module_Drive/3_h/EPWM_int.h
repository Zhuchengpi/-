
#ifndef EPWM_int_H
#define EPWM_int_H
#include "include_03.h"

#define   PWM_FREQ             10000  //10000
#define   ISR_FREQUENCY        7.5       // 7.5khz


//#define   SYSTEM_FREQUENCY     120
//#define	  PWM_PeriodMax        0X1770//((Uint16) (SYSTEM_FREQUENCY*100/2))   //6000
//#define	  PWM_HalfPerMax       0X0BB8//((Uint16) (PWM_PeriodMax/2))          //3000
#define   SYSTEM_FREQUENCY     90
#define   PWM_PeriodMax        0X1194//((Uint16) (SYSTEM_FREQUENCY*100/2))   //4500
#define   PWM_HalfPerMax       0X08CA//((Uint16) (PWM_PeriodMax/2))          //2250
#define	  PWM_Deadband         0X0078//((Uint16) (2.5*SYSTEM_FREQUENCY))         //120


#define   Normal_factor        162.379838f      //  PWM_HalfPerMax/Svpwm_Km   ��һ��ϵ��


void EPWM3_int(void); //����PWM��ʼ��
void HVDMC_Protection(void); //PWM�ı�����ʼ��
void PWMDAC_int(void);   // pwm��ΪRC�˲���DAC���
void START_CAR(void);  // ��ʼ������ƿ�PWM
void STOP_CAR(void);   // ͣ������ƹ�PWM

#endif  // end of EPWM_int_H definition

//===========================================================================
// End of file.
//===========================================================================
