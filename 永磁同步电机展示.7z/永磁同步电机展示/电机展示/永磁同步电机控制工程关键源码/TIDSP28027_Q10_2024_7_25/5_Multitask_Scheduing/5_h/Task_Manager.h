/*
 * Task_Manager.h
 *
 *  Created on: 2024��4��24��
 *      Author: ��Ƥ
 */

#ifndef _TASK_MANAGER_H_
#define _TASK_MANAGER_H_

#include <include_05.h>
typedef void ( *FTimer_P) ( void );

typedef struct
{
    Uint16 Task_Period;           //time out for calling function
    Uint16 Task_Count;
    FTimer_P Task_Function;     //Send function defines in application
} TaskTime;

void Timer_Task_Count(void);
void Execute_Task_List_RUN(void);
void Task_Manage_List_Init(void);
void Parameter_Debug(void);
void Task_LED(void);
void Deal_Fault(void);
void CAN_Recovery_Fault(void);
void task_send_Rece(void);
void PI_Debug(void);

#endif /* 5_MULTITASK_SCHEDUING_5_H_TASK_MANAGER_H_ */
