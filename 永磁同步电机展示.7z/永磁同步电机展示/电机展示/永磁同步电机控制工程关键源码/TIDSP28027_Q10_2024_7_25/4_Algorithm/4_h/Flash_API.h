/*
 * Flash_API.h
 *
 *  Created on: 2024��5��8��
 *      Author: ��Ƥ
 */

#ifndef FLASH_API_H_
#define FLASH_API_H_

//---------------------------------------------------------------------------
// For Portability, User Is Recommended To Use Following Data Type Size
// Definitions For 16-bit and 32-Bit Signed/Unsigned Integers:
//

#ifndef DSP28_DATA_TYPES
#define DSP28_DATA_TYPES
typedef int int16;
typedef long int32;
typedef unsigned int Uint16;
typedef unsigned long Uint32;
typedef float float32;
typedef long double float64;
#endif

/*---- DSP2833x Header Files -- from TI's website. ----------*/

/*---- flash program files -------------------------------------------------*/
#include "Flash2802x_API_Library.h"
//#include "include_04.h"
#define parm_size 10

//�ڴ����
typedef union
{
    struct
    {
        Uint16 SoftwareVersion;         //00�����汾
        Uint16 HardwareVersion;         //01Ӳ���汾
        Uint16 speed_kp;                //02�ٶȻ�KP
        Uint16 speed_ki;                //03�ٶȻ�Ki
        Uint16 reserve1;                //04����
        Uint16 reserve2;                //05����
        Uint16 reserve3;                //06����
        Uint16 reserve4;                //07����
        Uint16 reserve5;                //08����
        Uint16 reserve6;                //09����
    };
    Uint16 arry[parm_size];
} flash_Parm_memory_S;

extern flash_Parm_memory_S flash_Parm_memory;

/*---------------------------------------------------------------------------
 Functions used by this example
 *---------------------------------------------------------------------------*/
extern void flash_stort_init(void);
extern void parm_updata(void);

#endif /* 4_ALGORITHM_4_H_FLASH_API_H_ */
