

#ifndef _IDIAMAP_H_ 
#define _IDIAMAP_H_ 

#define Motor_MAX_Trq_Count (100+1)

#define Motor_MAX_Speed_Count 25

extern const float32 Id_Map[Motor_MAX_Speed_Count][Motor_MAX_Trq_Count];
extern const float32 Iq_Map[Motor_MAX_Speed_Count][Motor_MAX_Trq_Count];

#endif /* idqmap*/
