/*
 * include_04.h
 *
 *  Created on: 2024��3��12��
 *      Author: ��Ƥ
 */

#ifndef INCLUDE_04_H_
#define INCLUDE_04_H_

#include "ADC_Voltage.h"
#include "include_03.h"
#include "DSP28x_Project.h"
#include <DSP2802x_Device.h>
#include "MotorC_parameter.h"
#include "SVPWM.h"
#include "Axis_transform.h"
#include "FOC.h"
#include "Common_Math.h"
#include "PI_Cale.h"
#include "IdIqMap.h"
#include "Fault_Protect.h"
#include "SPI_Data_Process.h"
#include "SPI_Send_Receivce.h"
#include "Flash_API.h"
#include "Comparators.h"

#endif /* 4_ALGORITHM_4_H_INCLUDE_04_H_ */
