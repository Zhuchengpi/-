/*
 * Comparators.h
 *
 *  Created on: 2024��7��14��
 *      Author: ��Ƥ
 */

#ifndef COMPARATORS_H_
#define COMPARATORS_H_

extern void Comp_Init(void);



#endif /* 4_ALGORITHM_4_H_COMPARATORS_H_ */
