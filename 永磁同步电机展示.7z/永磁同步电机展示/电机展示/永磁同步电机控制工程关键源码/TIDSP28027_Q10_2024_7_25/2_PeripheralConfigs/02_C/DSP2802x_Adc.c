
#include "DSP2802x_Device.h"     // DSP2802x Headerfile Include File
#include "DSP2802x_Examples.h"   // DSP2802x Examples Include File

#define ADC_usDELAY  1000L

//---------------------------------------------------------------------------
// InitAdc:
//---------------------------------------------------------------------------
// This function initializes ADC to a known state.
//
// NOTE: ADC INIT IS DIFFERENT ON 2802x DEVICES COMPARED TO OTHER 28X DEVICES
//
void InitAdc(void)
{
    extern void DSP28x_usDelay(Uint32 Count);

    // *IMPORTANT*
    // The Device_cal function, which copies the ADC calibration values from TI reserved
    // OTP into the ADCREFSEL and ADCOFFTRIM registers, occurs automatically in the
    // Boot ROM. If the boot ROM code is bypassed during the debug process, the
    // following function MUST be called for the ADC to function according
    // to specification. The clocks to the ADC MUST be enabled before calling this
    // function.
    // See the device data manual and/or the ADC Reference
    // Manual for more information.

    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 1;
    (*Device_cal )();
    EDIS;

    // To powerup the ADC the ADCENCLK bit should be set first to enable
    // clocks, followed by powering up the bandgap, reference circuitry, and ADC core.
    // Before the first conversion is performed a 5ms delay must be observed
    // after power up to give all analog circuits time to power up and settle

    // Please note that for the delay function below to operate correctly the
    // CPU_RATE define statement in the DSP2802x_Examples.h file must
    // contain the correct CPU clock period in nanoseconds.
    EALLOW;
    AdcRegs.ADCCTL1.bit.ADCBGPWD = 1;      // Power ADC BG
    AdcRegs.ADCCTL1.bit.ADCREFPWD = 1;      // Power reference
    AdcRegs.ADCCTL1.bit.ADCPWDN = 1;      // Power ADC
    AdcRegs.ADCCTL1.bit.ADCENABLE = 1;      // Enable ADC
    AdcRegs.ADCCTL1.bit.ADCREFSEL = 0;      // Select interal BG
    EDIS;

    DELAY_US(ADC_usDELAY);         // Delay before converting ADC channels
}

void InitAdcAio()
{

    EALLOW;

    /* Configure ADC pins using AIO regs*/
// This specifies which of the possible AIO pins will be Analog input pins.
// NOTE: AIO1,3,5,7-9,11,13,15 are analog inputs in all AIOMUX1 configurations.
// Comment out other unwanted lines.
    GpioCtrlRegs.AIOMUX1.bit.AIO2 = 2; // Configure AIO2 for A2 (analog input) operation
    GpioCtrlRegs.AIOMUX1.bit.AIO4 = 2; // Configure AIO4 for A4 (analog input) operation
    GpioCtrlRegs.AIOMUX1.bit.AIO6 = 2; // Configure AIO6 for A6 (analog input) operation
    GpioCtrlRegs.AIOMUX1.bit.AIO10 = 2; // Configure AIO10 for B2 (analog input) operation
    GpioCtrlRegs.AIOMUX1.bit.AIO12 = 2; // Configure AIO12 for B4 (analog input) operation
    GpioCtrlRegs.AIOMUX1.bit.AIO14 = 2; // Configure AIO14 for B6 (analog input) operation

    EDIS;
}

/* AdcoffsetSelfCal-
 This function re-calibrates the ADC zero offset error by converting the VREFLO reference with
 the ADC and modifying the ADCOFFTRIM register. VREFLO is sampled by the ADC using an internal
 MUX select which connects VREFLO to A5 without sacrificing an external ADC pin. This
 function calls two other functions:
 - AdcChanSelect(channel) � selects the ADC channel to convert
 - AdcConversion()  initiates several ADC conversions and returns the average
 这个函数通过ADC转换VREFLO参考电压并修改ADCOFFTRIM寄存器来重新校准ADC的零偏置误差。VREFLO通过ADC内部多路复用器选择进行采样，该多路复用器将VREFLO连接到A5，而不会牺牲外部ADC引脚。这个函数调用了另外两个函数：

 AdcChanSelect(channel) - 选择要转换的ADC通道
 AdcConversion() - 发起多次ADC转换并返回平均值
 */
void AdcOffsetSelfCal(Uint16 set)
{
    //Uint16 AdcConvMean;
    EALLOW;
    AdcRegs.ADCCTL1.bit.ADCREFSEL = 0; //Select internal reference mode// 选择内部参考模式
    AdcRegs.ADCCTL1.bit.VREFLOCONV = 1; //Select VREFLO internal connection on B5
    AdcChanSelect(set);           //Select channel B5 for all SOC// 为所有SOC选择通道B5
    AdcRegs.ADCOFFTRIM.bit.OFFTRIM = 0; //Apply artificial offset (+80) to account for a negative offset that may reside in the ADC core// 应用人工偏移（+80）以补偿ADC核心中可能存在的负偏移
    AdcConversion();      //Capture ADC conversion on VREFLO// 捕获VREFLO上的ADC转换结果
    //AdcRegs.ADCOFFTRIM.bit.OFFTRIM = 80 - AdcConvMean;  //Set offtrim register with new value (i.e remove artical offset (+80) and create a two's compliment of the offset error)// 使用新值设置offtrim寄存器（即移除人工偏移（+80）并创建偏移误差的二进制补码）
    AdcRegs.ADCCTL1.bit.VREFLOCONV = 0; //Select external ADCIN5 input pin on B5
    EDIS;

}

/*  AdcChanSelect-
 This function selects the ADC channel to convert by setting all SOC channel selects to a single channel.

 * IMPORTANT * This function will overwrite previous SOC channel select settings. Recommend saving
 the previous settings.
 此函数通过将所有SOC通道选择设置为单个通道来选择要转换的ADC通道。
 */
void AdcChanSelect(Uint16 ch_no)
{
    ch_no = 0;
    AdcRegs.ADCSOC0CTL.bit.CHSEL = ch_no;
    AdcRegs.ADCSOC1CTL.bit.CHSEL = 1;
    AdcRegs.ADCSOC2CTL.bit.CHSEL = 2;
    AdcRegs.ADCSOC3CTL.bit.CHSEL = 3;
    AdcRegs.ADCSOC4CTL.bit.CHSEL = 4;
    AdcRegs.ADCSOC5CTL.bit.CHSEL = 5;
    AdcRegs.ADCSOC6CTL.bit.CHSEL = 6;
    AdcRegs.ADCSOC7CTL.bit.CHSEL = 7;
    AdcRegs.ADCSOC8CTL.bit.CHSEL = 8;
    AdcRegs.ADCSOC9CTL.bit.CHSEL = 9;
    AdcRegs.ADCSOC10CTL.bit.CHSEL = 10;
    AdcRegs.ADCSOC11CTL.bit.CHSEL = 11;
    AdcRegs.ADCSOC12CTL.bit.CHSEL = 12;
    AdcRegs.ADCSOC13CTL.bit.CHSEL = 13;
    AdcRegs.ADCSOC14CTL.bit.CHSEL = 14;
    AdcRegs.ADCSOC15CTL.bit.CHSEL = 15;
} //end AdcChanSelect

/* AdcConversion -
 This function initiates several ADC conversions and returns the average. It uses ADCINT1 and ADCINT2
 to "ping-pong" between SOC0-7 and SOC8-15 and is referred to as "ping-pong" sampling.

 * IMPORTANT * This function will overwrite previous ADC settings. Recommend saving previous settings.
 * 此函数启动多次ADC转换并返回平均值。它使用ADCINT1和ADCINT2在SOC0-7和SOC8-15之间进行“乒乓”操作，这被称为“乒乓”采样。
 */
void AdcConversion(void)
{
    Uint16 index, ACQPS_Value;
    // Uint16  ACQPS_Value;
    Uint32 Sum;

    index = 0;            //initialize index to 0// 将索引初始化为0
    //SampleSize  = 16;          //set sample size to 256 (**NOTE: Sample size must be multiples of 2^x where is an integer >= 4)// 将样本大小设置为256（**注意：样本大小必须是2的x次方的倍数，其中x是一个大于等于4的整数）
    Sum = 0;            //set sum to 0// 将和设置为0
    //Mean        = 1;          //initialize mean to known value// 将均值初始化为已知值

    //Set the ADC sample window to the desired value (Sample window = ACQPS + 1)// 将ADC采样窗口设置为所需值（采样窗口 = ACQPS + 1）
    ACQPS_Value = 11;
    AdcRegs.ADCSOC0CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC1CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC2CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC3CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC4CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC5CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC6CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC7CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC8CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC9CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC10CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC11CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC12CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC13CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC14CTL.bit.ACQPS = ACQPS_Value;
    AdcRegs.ADCSOC15CTL.bit.ACQPS = ACQPS_Value;

    //Enable ping-pong sampling

    // Enabled ADCINT1 and ADCINT2
    AdcRegs.INTSEL1N2.bit.INT1E = 1;
    AdcRegs.INTSEL1N2.bit.INT2E = 1;

    // Disable continuous sampling for ADCINT1 and ADCINT2// 禁用ADCINT1和ADCINT2的连续采样
    AdcRegs.INTSEL1N2.bit.INT1CONT = 0;
    AdcRegs.INTSEL1N2.bit.INT2CONT = 0;

    AdcRegs.ADCCTL1.bit.INTPULSEPOS = 1; //ADCINTs trigger at end of conversion// ADCINT在转换结束时触发

    // Setup ADCINT1 and ADCINT2 trigger source// 设置ADCINT1和ADCINT2的触发源
    AdcRegs.INTSEL1N2.bit.INT1SEL = 6;   //EOC6 triggers ADCINT1// EOC6触发ADCINT1
    AdcRegs.INTSEL1N2.bit.INT2SEL = 14;     //EOC14 triggers ADCINT2

    // Setup each SOC's ADCINT trigger source// 设置每个SOC的ADCINT触发源
    AdcRegs.ADCINTSOCSEL1.bit.SOC0 = 2;    //ADCINT2 starts SOC0-7
    AdcRegs.ADCINTSOCSEL1.bit.SOC1 = 2;
    AdcRegs.ADCINTSOCSEL1.bit.SOC2 = 2;
    AdcRegs.ADCINTSOCSEL1.bit.SOC3 = 2;
    AdcRegs.ADCINTSOCSEL1.bit.SOC4 = 2;
    AdcRegs.ADCINTSOCSEL1.bit.SOC5 = 2;
    AdcRegs.ADCINTSOCSEL1.bit.SOC6 = 2;
    AdcRegs.ADCINTSOCSEL1.bit.SOC7 = 2;
    AdcRegs.ADCINTSOCSEL2.bit.SOC8 = 1;    //ADCINT1 starts SOC8-15
    AdcRegs.ADCINTSOCSEL2.bit.SOC9 = 1;
    AdcRegs.ADCINTSOCSEL2.bit.SOC10 = 1;
    AdcRegs.ADCINTSOCSEL2.bit.SOC11 = 1;
    AdcRegs.ADCINTSOCSEL2.bit.SOC12 = 1;
    AdcRegs.ADCINTSOCSEL2.bit.SOC13 = 1;
    AdcRegs.ADCINTSOCSEL2.bit.SOC14 = 1;
    AdcRegs.ADCINTSOCSEL2.bit.SOC15 = 1;

    DELAY_US(ADC_usDELAY);               // Delay before converting ADC channels

    //ADC Conversion

    AdcRegs.ADCSOCFRC1.all = 0x00FF; // Force Start SOC0-7 to begin ping-pong sampling// 强制启动SOC0-7以开始乒乓采样
    AdcRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;
    AdcRegs.ADCINTFLGCLR.bit.ADCINT2 = 1;

    // while( index < SampleSize ){

    //Wait for ADCINT1 to trigger, then add ADCRESULT0-7 registers to sum// 等待ADCINT1触发，然后将ADCRESULT0-7寄存器添加到和中
    //while (AdcRegs.ADCINTFLG.bit.ADCINT1 == 0){}
    AdcRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //Must clear ADCINT1 flag since INT1CONT = 0// 由于INT1CONT = 0，必须清除ADCINT1标志
    Sum += AdcResult.ADCRESULT0;
    Sum += AdcResult.ADCRESULT1;
    Sum += AdcResult.ADCRESULT2;
    Sum += AdcResult.ADCRESULT3;
    Sum += AdcResult.ADCRESULT4;
    Sum += AdcResult.ADCRESULT5;
    Sum += AdcResult.ADCRESULT6;
    Sum += AdcResult.ADCRESULT7;

    //Wait for ADCINT2 to trigger, then add ADCRESULT8-15 registers to sum// 等待ADCINT2触发，然后将ADCRESULT8-15寄存器添加到和中
    //while (AdcRegs.ADCINTFLG.bit.ADCINT2 == 0){}
    AdcRegs.ADCINTFLGCLR.bit.ADCINT2 = 1; //Must clear ADCINT2 flag since INT2CONT = 0
    Sum += AdcResult.ADCRESULT8;
    Sum += AdcResult.ADCRESULT9;
    Sum += AdcResult.ADCRESULT10;
    Sum += AdcResult.ADCRESULT11;
    Sum += AdcResult.ADCRESULT12;
    Sum += AdcResult.ADCRESULT13;
    Sum += AdcResult.ADCRESULT14;
    Sum += AdcResult.ADCRESULT15;

    index += 16;

    // } // end data collection

    //Disable ADCINT1 and ADCINT2 to STOP the ping-pong sampling
    AdcRegs.INTSEL1N2.bit.INT1E = 0;
    AdcRegs.INTSEL1N2.bit.INT2E = 0;

    //Mean = Sum / SampleSize;    //Calculate average ADC sample value// 计算ADC样本值的平均值

    //return Mean;                //return the average

}   //end AdcConversion

//===========================================================================
// End of file.
//===========================================================================
